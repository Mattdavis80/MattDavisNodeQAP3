--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16rc1
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE breweries;
--
-- Name: breweries; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE breweries WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Canada.1252';


ALTER DATABASE breweries OWNER TO postgres;

\connect breweries

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: beers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beers (
    id integer NOT NULL,
    name character varying NOT NULL,
    abv integer NOT NULL,
    ibu integer NOT NULL,
    category_id integer NOT NULL,
    brewery_id integer NOT NULL
);


ALTER TABLE public.beers OWNER TO postgres;

--
-- Name: beers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.beers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.beers_id_seq OWNER TO postgres;

--
-- Name: beers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.beers_id_seq OWNED BY public.beers.id;


--
-- Name: breweries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.breweries (
    id integer NOT NULL,
    name character varying NOT NULL,
    city character varying NOT NULL,
    year_established integer NOT NULL,
    owner character varying NOT NULL
);


ALTER TABLE public.breweries OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: beers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beers ALTER COLUMN id SET DEFAULT nextval('public.beers_id_seq'::regclass);


--
-- Data for Name: beers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beers (id, name, abv, ibu, category_id, brewery_id) FROM stdin;
\.
COPY public.beers (id, name, abv, ibu, category_id, brewery_id) FROM '$$PATH$$/4797.dat';

--
-- Data for Name: breweries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.breweries (id, name, city, year_established, owner) FROM stdin;
\.
COPY public.breweries (id, name, city, year_established, owner) FROM '$$PATH$$/4795.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description) FROM stdin;
\.
COPY public.categories (id, name, description) FROM '$$PATH$$/4794.dat';

--
-- Name: beers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.beers_id_seq', 1, true);


--
-- Name: beers beers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beers
    ADD CONSTRAINT beers_pkey PRIMARY KEY (id);


--
-- Name: breweries breweries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.breweries
    ADD CONSTRAINT breweries_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: beers brewery_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beers
    ADD CONSTRAINT brewery_id FOREIGN KEY (brewery_id) REFERENCES public.breweries(id);


--
-- Name: beers category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beers
    ADD CONSTRAINT category_id FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- PostgreSQL database dump complete
--

